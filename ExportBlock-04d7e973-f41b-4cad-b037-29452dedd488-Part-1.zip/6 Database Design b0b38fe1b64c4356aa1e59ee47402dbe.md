# 6. Database Design

# Database Design (Schema)

This is the conceptual schema. Implementation will map to Firestore collections/documents and Storage objects.

## Users

| Field | Type | Notes |
| --- | --- | --- |
| user_id | string | Auth uid |
| name | string | Display name |
| language | string | e.g., hi, en |
| location | object | { state, district, village, lat, lon } |

## Farm

| Field | Type | Notes |
| --- | --- | --- |
| land_size | number | acres/hectares |
| soil_type | string | loam, clay, sandy… |
| water_source | string | canal/borewell/rainfed |
| farming_method | string | organic/conventional/mixed |

## Crop

| Field | Type | Notes |
| --- | --- | --- |
| crop_name | string | e.g., wheat |
| sowing_date | date | ISO date |
| crop_stage | string | germination/veg/flowering/… |

## Disease History

| Field | Type | Notes |
| --- | --- | --- |
| image | string | Storage path / URL |
| disease | string | label |
| confidence | number | 0–1 |
| treatment | string | structured + text |

## Weather History

| Field | Type | Notes |
| --- | --- | --- |
| date | date | daily summary |
| temperature | object | { min, max } |
| rainfall | number | mm |

## Recommendations

| Field | Type | Notes |
| --- | --- | --- |
| advice | string | recommended action |
| reason | string | explanation |
| confidence | number | 0–1 |
| context | object | crop, stage, weather refs |
| model_version | string | auditability |

## Chat History

| Field | Type | Notes |
| --- | --- | --- |
| messages | array | { role, text, timestamp } |
| timestamp | datetime | conversation time |
| summary | string | optional condensed memory |