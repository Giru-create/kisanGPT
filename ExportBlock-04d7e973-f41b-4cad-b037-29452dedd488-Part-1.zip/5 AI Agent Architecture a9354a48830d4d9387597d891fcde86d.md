# 5. AI Agent Architecture

# AI Agent Architecture Documentation

## Architecture Overview

A multi-agent system where a central **Agent Controller** routes user requests to specialized agents (crop, weather, disease, market, memory) and composes final responses with citations, confidence, and next actions.

## Agent Controller

**Role**

- Manage communication between AI agents
- Decide routing based on intent (chat vs disease scan vs market)
- Enforce safety policies and response formatting

**Responsibilities**

- Input normalization (language, location, crop stage)
- Tool calling (weather API, market prices, retrieval)
- Response composition (actionable steps + why + confidence)
- Feedback capture (helpful/not helpful, outcome)

---

## Crop Agent

**Purpose**

Provide crop recommendations and farming advice.

**Inputs**

- Location
- Soil
- Season
- Crop stage

**Output**

- Recommendations
- Explanation
- Confidence score

**Notes**

- Must reference current crop stage and local seasonality.
- Include “Do / Don’t” steps and safe-use disclaimers.

---

## Weather Agent

**Purpose**

Convert weather data into farming actions.

**Inputs**

- Location
- Crop
- Weather API data

**Output**

- Alerts
- Recommendations

**Notes**

- Convert raw values into actions: irrigation, spraying windows, disease risk.
- Provide time windows (“Next 6 hours”, “Tomorrow morning”).

---

## Disease Agent

**Purpose**

Detect crop diseases from images.

**Input**

- Crop image

**Output**

- Disease name
- Confidence
- Symptoms
- Treatment

**Notes**

- If confidence low: ask for more photos/angles + crop stage + recent weather.
- Provide safe guidance and escalation suggestions.

---

## Market Agent

**Purpose**

Help farmers sell crops better.

**Output**

- Market prices
- Price comparison
- Selling suggestions

**Notes**

- Emphasize nearest markets + trends + net price after transport.
- Provide “hold vs sell” suggestion with assumptions.

---

## Memory Agent

**Purpose**

Remember farmer history.

**Store**

- Previous crops
- Diseases
- Recommendations
- Yield

**Notes**

- Store as structured events: {date, crop, issue, action, outcome}.
- Use memory to personalize future recommendations.