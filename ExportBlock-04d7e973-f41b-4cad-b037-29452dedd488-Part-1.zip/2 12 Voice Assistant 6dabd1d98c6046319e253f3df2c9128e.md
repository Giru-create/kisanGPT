# 2.12 Voice Assistant

# Voice Assistant

## Feature Name

Voice Assistant

## Purpose

Enable hands-free, low-literacy interactions via voice input and voice output in local languages.

## User Problem Solved

Many farmers prefer speaking; typing is slow and language keyboards are challenging.

## Primary User Flow

1. Farmer taps mic and speaks.
2. App transcribes and confirms intent.
3. Assistant replies with voice + on-screen steps.

## Inputs Required

- Audio
- Language selection (or auto-detect)
- Farm context

## AI Processing

- Speech-to-text
- Intent detection
- Text-to-speech

## Output

- Spoken recommendations + clickable checklist

## User Benefits

- Faster and more inclusive UX
- Higher engagement

## Edge Cases / Safety

- Noisy environment → ask to repeat, show text confirmation.

## Telemetry / Success Metrics

- Voice usage rate
- STT error rate proxy (corrections)

## Future Improvements

- Offline voice packs (limited)
- Dialect adaptation
- Voice shortcuts for common tasks