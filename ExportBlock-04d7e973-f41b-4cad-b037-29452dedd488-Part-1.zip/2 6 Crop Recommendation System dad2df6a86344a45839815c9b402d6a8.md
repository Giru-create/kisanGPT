# 2.6 Crop Recommendation System

# Crop Recommendation System

## Feature Name

Crop Recommendation System

## Purpose

Help farmers choose the best crop(s) for a season based on location, soil, water availability, and market signals.

## User Problem Solved

Crop selection is risky and often based on limited local advice and uncertain prices.

## Primary User Flow

1. Farmer opens “Recommend Crops”.
2. Confirms farm details and upcoming season.
3. Gets a ranked list with reasoning and requirements.

## Inputs Required

- Location
- Soil type
- Water source
- Season window
- Past crops (optional)

## AI Processing

- Match agro-climatic suitability.
- Filter by water constraints.
- Include market demand/price trends (if available).

## Output

- Ranked crop list
- Input requirements (seed, irrigation needs)
- Risk flags and confidence

## User Benefits

- Better seasonal planning
- Reduced crop failure risk

## Edge Cases / Safety

- Avoid recommending restricted crops without compliance notes.

## Telemetry / Success Metrics

- Recommendation view → selection conversion
- Outcome tracking in pilots

## Future Improvements

- Variety-level recommendations
- Profit simulation (inputs + prices)
- Government scheme integration