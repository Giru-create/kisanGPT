# KisanGPT — Product Documentation

# Overview

KisanGPT is an AI-powered farming companion designed to feel like “an agricultural expert with me 24/7”.

Use this workspace as the single source of truth for:

- Product requirements and scope decisions
- Feature specs (for engineering + AI agents)
- User journeys and UX flows
- Technical architecture and data model
- Design system and UI documentation
- Development roadmap and coding standards

## How to use (for humans + AI coding agents)

1. Start with **PRD** to understand the “why” and success metrics.
2. Use **Feature Documentation** for build-ready specs and acceptance criteria.
3. Reference **TRD + AI Agent Architecture + Database Design** for implementation details.
4. Use **UI/UX Documentation + Design System** for screens, components, and visual language.
5. Follow **Development Roadmap** for sequencing.
6. Enforce **AI Coding Instructions (OpenCode)** for code style, structure, and quality bars.

[2. Feature Documentation](2%20Feature%20Documentation%2007ea6ab1f0e34824a3761de14695af4f.md)

[3. User Journey Documentation](3%20User%20Journey%20Documentation%20c85cf22401384b749ce87ba50dab965e.md)

[7. UI/UX Documentation](7%20UI%20UX%20Documentation%2069f69f265d214bc0815513f7d71c67df.md)

[8. Design System](8%20Design%20System%20923c6dfb22ef47d5b7a9dded1d2f1464.md)

[5. AI Agent Architecture](5%20AI%20Agent%20Architecture%20a9354a48830d4d9387597d891fcde86d.md)

[6. Database Design](6%20Database%20Design%20b0b38fe1b64c4356aa1e59ee47402dbe.md)

[1. Product Requirements Document (PRD)](1%20Product%20Requirements%20Document%20(PRD)%209df63b0e21fb42389ba7a4c50132554c.md)

[9. Development Roadmap](9%20Development%20Roadmap%20304576f9a9734c20a259c66d294023a7.md)

[10. AI Coding Instructions (OpenCode)](10%20AI%20Coding%20Instructions%20(OpenCode)%205c7f7d792a6748c1b35ec6055b657ec4.md)

[4. Technical Requirements Document (TRD)](4%20Technical%20Requirements%20Document%20(TRD)%20b7086e2bc8d9473c8bc3a97aefa82372.md)