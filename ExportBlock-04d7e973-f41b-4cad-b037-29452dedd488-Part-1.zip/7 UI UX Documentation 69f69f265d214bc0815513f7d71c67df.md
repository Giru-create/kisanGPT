# 7. UI/UX Documentation

# UI/UX Documentation

## Landing Page

**Purpose**

Introduce KisanGPT and quickly communicate trust + benefits.

**Sections**

- Hero (value prop + language selector)
- Features (cards)
- Farmer Benefits (before/after outcomes)
- CTA (Get started / Try demo)

**Primary CTAs**

- “Get started”
- “Scan crop disease”
- “Ask KisanGPT”

---

## Farmer Dashboard

**Components**

- Farmer greeting
- Farm health score (0–100) + drivers
- Weather card (today + next 48h)
- Crop health card (stage + risk flags)
- Market card (top crops + nearest mandi)
- Today’s tasks (action checklist)

**Key UX notes**

- Show 1–3 top actions only; avoid overwhelming.
- Provide “Why am I seeing this?” explanation for trust.

---

## AI Assistant Screen

**Components**

- Chat interface
- Voice button
- Image upload
- Suggested questions

**Suggested prompts**

- “What should I do today for my crop?”
- “Is it safe to spray today?”
- “How much water should I give?”

---

## Disease Scanner

**Components**

- Image upload (multi-image)
- AI analysis (confidence + symptoms)
- Treatment recommendation (step-by-step)
- Safety warnings + escalation option

---

## Market Screen

**Components**

- Crop prices
- Nearby markets
- Price trends (7/30 days)
- Net price calculator (transport + fees)

---

## Profile Screen

**Components**

- Farmer details
- Farm information
- History (crops, issues, actions, yields)