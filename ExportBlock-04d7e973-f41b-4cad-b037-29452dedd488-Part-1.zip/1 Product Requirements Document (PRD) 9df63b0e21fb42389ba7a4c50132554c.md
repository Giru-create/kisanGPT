# 1. Product Requirements Document (PRD)

# Product Requirements Document (PRD)

## Product Name

KisanGPT

## Product Vision

KisanGPT is an AI farming companion that helps farmers make better decisions throughout their farming journey — from selecting crops to managing diseases, understanding weather, improving irrigation, and selling harvest at better prices.

## Mission Statement

Make expert-grade, locally relevant farming guidance accessible to every farmer, in their language, at the moment decisions are made.

## Problem Statement

Farmers make high-stakes decisions with incomplete information (weather, pests/diseases, irrigation timing, input selection, and market prices). Delayed or wrong decisions lead to yield loss, higher costs, and income uncertainty.

## Current Problems Faced by Farmers

- Fragmented information across advisors, WhatsApp, YouTube, local shops, and government portals
- Late disease detection and incorrect pesticide/fertilizer usage
- Weather uncertainty and lack of actionable recommendations
- Irrigation inefficiency and rising water/electricity costs
- Poor record-keeping (inputs, activities, yields, issues)
- Limited market transparency and weak bargaining power
- Language and literacy barriers for digital tools

## Proposed Solution

A mobile-first AI platform that:

- Builds a **digital farm profile** (location, land, soil, crops, stage, practices)
- Provides a **chat + voice** AI assistant with locally contextual guidance
- Offers **AI vision disease detection** from crop images
- Converts **weather data** into actionable farming alerts
- Suggests irrigation timing, crop choices, and schedules
- Tracks farm history using a **memory system**
- Surfaces **market price intelligence** to improve selling decisions

## Target Users

- Small and marginal farmers (primary)
- Medium/large farmers (secondary)
- Farmer advisors / FPO staff (tertiary, “pro” workflows)

## User Personas

| Persona | Context | Goals | Constraints |
| --- | --- | --- | --- |
| Smallholder Farmer | 1–3 acres, mixed crops | Reduce risk, increase yield | Low tech comfort, tight budget |
| Commercial Farmer | 5–50 acres, mono-crop | Optimize inputs, automation | Wants accuracy + speed |
| FPO Advisor | Supports 100–1000 farmers | Standardize guidance, reporting | Needs multi-farm view |

## Farmer Pain Points

- “I don’t know what to do today for my crop.”
- “Is this disease? What medicine should I use?”
- “Will it rain? Should I irrigate or spray now?”
- “Am I spending too much? Will I be profitable?”
- “Where should I sell? What price is fair?”

## Product Goals

- Deliver **actionable** daily guidance (not just information)
- Improve early detection and correct treatment of diseases
- Reduce irrigation water usage and prevent stress events
- Increase farmer income via better decisions and market timing
- Build trust through transparency, safety checks, and explainability

## Non-Goals

- Replace certified agronomists for high-risk, regulated decisions
- Provide financial lending/insurance in v1 (may integrate later)
- Guarantee yields or prices (we provide best-effort guidance)

## Unique Value Proposition

“Personalized, always-on agricultural expertise that understands your farm, your crop stage, and your local conditions.”

## Competitive Advantage

- Farm context + memory improves recommendation relevance over time
- Multi-modal: chat + voice + image
- Action-oriented outputs (tasks, alerts, next steps)
- Local language and localized agronomy knowledge (iteratively expanded)

## Success Metrics

### Activation & Retention

- % of new users completing farm setup
- D7 / D30 retention
- Weekly active farmers (WAF)

### Value Delivery

- 
    
    # of actionable recommendations accepted
    
- Disease detection accuracy (measured set) + time-to-detection improvement
- Reduction in irrigation events or water usage (self-reported/estimated)
- Increase in net profit (pilot cohorts)

### Trust & Safety

- Recommendation feedback rating
- “Harmful suggestion” incident rate (target: near-zero)
- Escalations to human expert (and resolution rate)

## Future Vision

- Fully proactive farm copilot that plans the season end-to-end
- Multi-agent orchestration across crops, weather, market, and irrigation
- Regional language expansion + offline/low bandwidth optimization
- Integrations: IoT/sensors, satellite imagery, govt advisories, FPO workflows