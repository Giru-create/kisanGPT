# 2.3 Crop Disease Detection (AI Vision)

# Crop Disease Detection using AI Vision

## Feature Name

Crop Disease Detection (AI Vision)

## Purpose

Detect likely crop diseases/pest issues from images and convert detection into safe treatment guidance.

## User Problem Solved

Farmers often identify diseases late or incorrectly, leading to yield loss and wasted inputs.

## Primary User Flow

1. Farmer opens “Scan Disease”.
2. Uploads 1–3 photos (leaf close-up + whole plant + field view).
3. Selects crop (or auto-detected).
4. Receives diagnosis with confidence + symptoms + next steps.
5. Saves to Disease History.

## Inputs Required

- Crop image(s)
- Crop type (explicit or inferred)
- Crop stage (optional but recommended)
- Location + recent weather (optional)

## AI Processing

- Image quality checks (blur, lighting) and prompt for retake.
- Vision classification (disease/pest/deficiency).
- Cross-check with crop + season + region plausibility.
- Generate treatment plan with safety notes.

## Output

- Top disease candidates + confidence
- Symptom checklist
- Treatment steps (non-chemical + chemical options where appropriate)
- “When to escalate” guidance

## User Benefits

- Early detection
- Correct action timing
- Reduced unnecessary spraying

## Edge Cases / Safety

- Low confidence → request more angles or field context.
- Chemical guidance → include dosage disclaimers and local label compliance.

## Telemetry / Success Metrics

- % successful scans (usable images)
- Diagnosis confidence distribution
- Follow-up feedback/outcome capture

## Future Improvements

- On-device pre-checks for image quality
- Region-specific disease models
- Multi-issue detection (nutrient + pest + disease)