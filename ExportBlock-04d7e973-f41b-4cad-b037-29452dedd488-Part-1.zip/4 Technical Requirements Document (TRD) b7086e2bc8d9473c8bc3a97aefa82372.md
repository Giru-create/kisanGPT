# 4. Technical Requirements Document (TRD)

# Technical Requirements Document (TRD)

## Frontend

**Technology**

- Next.js 15
- React
- TypeScript
- Tailwind CSS
- shadcn/ui
- Framer Motion

**Key requirements**

- Mobile-first responsive UI (Hindi + English first; i18n-ready)
- Offline-tolerant UX (cache last state, queue actions)
- Image upload compression + progress states
- Accessibility: readable typography, large touch targets

## Backend

**Technology**

- Python
- FastAPI

**Key requirements**

- Modular service architecture (auth, farm profile, chat, vision, weather, market)
- Rate limiting + abuse protection
- Observability: structured logs, traces, model call metrics
- Background jobs for proactive alerts (cron/queue)

## AI Layer

**Technology**

- Google Gemini API
- Gemini Vision
- LangGraph (future)

**Key requirements**

- Prompt templates versioned in repo
- Tool/function calling for deterministic actions (weather fetch, price fetch, memory retrieval)
- Safety layer: pesticide/medicine guidance guardrails + disclaimers + escalation
- Evaluation harness (golden sets for disease & advice)

## Database

**Technology**

- Firebase

**Services**

- Firebase Authentication
- Firestore
- Firebase Storage

**Key requirements**

- Multi-tenant by user_id
- Auditability for recommendations (inputs, model version, outputs)
- Storage rules to protect images & PII

## Memory System

**Technology**

- Vector Database
- ChromaDB
- Embeddings

**Key requirements**

- Store summarized, structured “farm events” (not raw long chats only)
- Retrieval with recency + relevance
- PII-aware storage policy

## Deployment

**Frontend**

- Vercel

**Backend**

- Render / Railway

**Key requirements**

- Separate staging + production
- Secrets management (API keys)
- Cost monitoring (LLM calls, storage, bandwidth)