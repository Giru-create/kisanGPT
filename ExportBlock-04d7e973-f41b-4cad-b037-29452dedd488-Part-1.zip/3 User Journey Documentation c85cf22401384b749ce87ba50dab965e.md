# 3. User Journey Documentation

# User Journey Documentation

## New Farmer Flow

1. Landing Page  
    
    ↓  
    
2. Registration  
    
    ↓  
    
3. Farmer Profile Setup  
    
    ↓  
    
4. Farm Details  
    
    ↓  
    
5. Crop Information  
    
    ↓  
    
6. Dashboard  

### Notes

- Keep setup under 3 minutes.
- Allow “skip for now” with progressive profiling prompts.

## Daily Farmer Experience

1. Open App  
    
    ↓  
    
2. View Farm Health  
    
    ↓  
    
3. Check Weather  
    
    ↓  
    
4. See Today’s Tasks  
    
    ↓  
    
5. Ask AI  
    
    ↓  
    
6. Upload Crop Image  
    
    ↓  
    
7. Receive Recommendations  

### Core loops to optimize

- “Check tasks → complete → improve farm health score”
- “Spot issue → scan image → treat correctly”
- “Weather alert → take action → avoid loss”