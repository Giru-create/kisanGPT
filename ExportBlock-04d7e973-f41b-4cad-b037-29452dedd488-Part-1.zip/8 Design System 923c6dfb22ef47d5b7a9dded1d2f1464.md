# 8. Design System

# Design System

## Design Principles

- Minimal, clean, trustworthy
- Farmer-friendly and mobile-first
- High contrast, readable typography
- Action-oriented UI (tasks, alerts, next steps)

## Color Palette (proposed)

| Token | Usage | Hex |
| --- | --- | --- |
| Primary / Green | Primary actions, success | #1B7F3A |
| Secondary / Soil | Accent, illustrations | #7A5C3E |
| Sky / Info | Weather, info states | #2F80ED |
| Warning | Alerts | #F2994A |
| Danger | Critical | #EB5757 |
| Neutral / Text | Body text | #1F2937 |
| Neutral / BG | Background | #F8FAFC |

## Typography

- Headings: Inter / system
- Body: Inter / system
- Hindi/Indic: Noto Sans Devanagari fallback

## Components

### Buttons

- Primary: solid green
- Secondary: outline
- Destructive: red
- Loading: spinner + disabled

### Cards

- Rounded, subtle shadow
- Clear title + one key metric + CTA

### Forms

- Large inputs, simple validation messages
- Progressive disclosure for long setups

### Navigation

- Bottom nav (Home, Ask, Scan, Market, Profile)
- Use badges for alerts/tasks

### Icons

- Simple line icons, consistent stroke
- Use illustrative icons for crops/weather only when helpful

## Mobile Responsiveness

- Minimum touch target: 44px
- Support low-end Android devices
- Optimize images and animations (reduce motion)