# 10. AI Coding Instructions (OpenCode)

# AI Coding Instructions (OpenCode)

These rules are mandatory for AI coding agents generating code for KisanGPT.

## General Coding Rules

- Use **TypeScript** for frontend and shared types.
- Prefer **reusable components** and avoid copy-paste UI.
- Follow **clean architecture**:
    - UI layer (pages/screens)
    - Domain layer (use-cases, types)
    - Data layer (API clients, repositories)
- Use a **modular backend** (FastAPI routers by domain).
- Write scalable code with clear boundaries and interfaces.
- Add error handling for:
    - network failures
    - model failures
    - invalid inputs
    - permission/authorization issues
- Add loading states for every async interaction.
- Add documentation:
    - README for setup
    - inline docstrings where logic is non-trivial
    - API schemas and examples

## Frontend Conventions

- Next.js App Router
- Tailwind + shadcn/ui for consistent UI primitives
- Use Framer Motion sparingly (performance-first)
- Use Zod for validation
- Use React Query/SWR for data fetching (pick one consistently)

## Backend Conventions (FastAPI)

- Pydantic models for request/response
- Versioned API routes: `/api/v1/...`
- Dependency injection for services
- Centralized exception handling with consistent error shapes

## AI / Prompting Conventions

- Prompt templates must be versioned and testable.
- Every AI output must include:
    - recommended action(s)
    - short reasoning
    - confidence score
    - safety notes when relevant
- Log: inputs, model, latency, tokens (where possible)
- Avoid hallucinated facts; ask clarifying questions when needed.

## Quality Bar (Definition of Done)

- [ ]  Lint passes
- [ ]  Types are correct
- [ ]  No hardcoded secrets
- [ ]  Basic unit tests for core logic
- [ ]  Manual QA steps written
- [ ]  Clear instructions to run locally