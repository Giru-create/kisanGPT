# 2.8 Market Price Intelligence

# Market Price Intelligence

## Feature Name

Market Price Intelligence

## Purpose

Help farmers understand current prices, nearby markets, and selling timing suggestions.

## User Problem Solved

Farmers lack transparent price discovery and often sell at suboptimal markets/prices.

## Primary User Flow

1. Farmer opens Market screen.
2. Selects crop.
3. Sees prices across nearby mandis + trends.
4. Gets selling suggestion (best market + expected net price).

## Inputs Required

- Location
- Crop
- Market price feeds (APMC/partners)
- Transport assumptions (optional)

## AI Processing

- Rank markets by distance and net price.
- Detect trend direction and volatility.

## Output

- Price table + trend charts
- Best market recommendation + reasoning

## User Benefits

- Better bargaining power
- Improved income

## Edge Cases / Safety

- Data gaps → show “last updated” and confidence.

## Telemetry / Success Metrics

- Market screen usage
- Clicks on best-market suggestion

## Future Improvements

- Buyer leads and demand signals
- Storage/hold recommendations with risk
- Community price reporting