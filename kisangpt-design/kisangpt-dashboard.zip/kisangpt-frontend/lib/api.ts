import type {
  AIRecommendation,
  WeatherSummary,
  MarketSummary,
  DiseaseAlert,
  SchemeSummary,
} from "@/types/dashboard";

/**
 * Thin fetch wrappers around the EXISTING KisanGPT backend.
 * Adjust the base path / response mapping to match your real API contract —
 * these paths assume the conventions implied by the current feature set
 * (AI Advisor, Weather, Market, Disease Detection, Schemes).
 * No new endpoints are introduced here.
 */

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  if (!res.ok) {
    throw new Error(`Request to ${path} failed with ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  getAIRecommendation: () =>
    request<AIRecommendation>("/ai/recommendation/today"),

  getWeatherSummary: () => request<WeatherSummary>("/weather/summary"),

  getMarketSummary: (crop?: string) =>
    request<MarketSummary>(`/market/summary${crop ? `?crop=${crop}` : ""}`),

  getDiseaseAlerts: () => request<DiseaseAlert[]>("/disease/alerts"),

  getSchemes: () => request<SchemeSummary[]>("/schemes/eligible"),

  getCropHealthScore: () =>
    request<{ score: number }>("/farm/health-score").then((r) => r.score),
};
