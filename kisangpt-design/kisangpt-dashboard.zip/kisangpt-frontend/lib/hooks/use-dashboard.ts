"use client";

import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export function useAIRecommendation() {
  return useQuery({
    queryKey: ["ai-recommendation"],
    queryFn: api.getAIRecommendation,
    staleTime: 5 * 60 * 1000,
  });
}

export function useWeatherSummary() {
  return useQuery({
    queryKey: ["weather-summary"],
    queryFn: api.getWeatherSummary,
    staleTime: 15 * 60 * 1000,
  });
}

export function useMarketSummary(crop?: string) {
  return useQuery({
    queryKey: ["market-summary", crop],
    queryFn: () => api.getMarketSummary(crop),
    staleTime: 10 * 60 * 1000,
  });
}

export function useDiseaseAlerts() {
  return useQuery({
    queryKey: ["disease-alerts"],
    queryFn: api.getDiseaseAlerts,
    staleTime: 10 * 60 * 1000,
  });
}

export function useSchemes() {
  return useQuery({
    queryKey: ["schemes"],
    queryFn: api.getSchemes,
    staleTime: 60 * 60 * 1000,
  });
}

export function useCropHealthScore() {
  return useQuery({
    queryKey: ["crop-health-score"],
    queryFn: api.getCropHealthScore,
    staleTime: 15 * 60 * 1000,
  });
}
