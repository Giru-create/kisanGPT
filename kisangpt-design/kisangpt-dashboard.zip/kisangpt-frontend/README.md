# KisanGPT — Dashboard (frontend only)

This is the first feature slice of the KisanGPT redesign, built on the design
system delivered earlier (indigo/gold/green tokens, Instrument Sans + Inter +
IBM Plex Mono, 4pt spacing, motion tokens). It ships **only the Dashboard**,
per the brief — every other nav item routes to a placeholder for now.

## What's included

```
app/
  layout.tsx          root layout, fonts, providers
  providers.tsx        React Query client
  globals.css           design tokens as HSL CSS variables (light + dark)
  dashboard/
    page.tsx             the dashboard screen
    loading.tsx          route-level skeleton
components/
  ui/                    primitives: button, card, badge, skeleton, state-message
  layout/                sidebar, mobile bottom nav, app shell
  dashboard/              AI recommendation card, stat card, weather/market/
                          disease/scheme widgets, AI-thinking animation
lib/
  api.ts                 fetch wrappers around your EXISTING backend routes
  hooks/use-dashboard.ts React Query hooks (weather, market, disease, schemes,
                          AI recommendation, crop health score)
store/use-app-store.ts   Zustand — sidebar collapse, mobile nav open state
types/dashboard.ts       shared TypeScript types
tailwind.config.ts
```

## Wiring to your real backend

`lib/api.ts` assumes REST endpoints under `NEXT_PUBLIC_API_BASE_URL` (defaults
to `/api`):

- `GET /ai/recommendation/today`
- `GET /weather/summary`
- `GET /market/summary?crop=...`
- `GET /disease/alerts`
- `GET /schemes/eligible`
- `GET /farm/health-score`

Update the paths and response shapes in `lib/api.ts` and `types/dashboard.ts`
to match your actual API contract — no new backend behavior is assumed beyond
what's listed in the brief (AI Advisor, Weather, Market, Disease Detection,
Government Schemes).

## Install

```bash
npm install next react react-dom typescript \
  @tanstack/react-query zustand framer-motion \
  class-variance-authority clsx tailwind-merge tailwindcss-animate \
  lucide-react @radix-ui/react-slot
npm install -D tailwindcss postcss autoprefixer @types/react @types/node
```

Copy this folder's contents into your existing Next.js App Router project
(merge `app/`, `components/`, `lib/`, `store/`, `types/`, and
`tailwind.config.ts`). Visit `/dashboard`.

## Next steps

Once the dashboard is approved, the same primitives (`Button`, `Card`,
`Badge`, `Skeleton`, `StateMessage`) and the same widget pattern (React Query
hook → loading / error / empty / success states) extend directly to AI
Advisor, Weather, Market, Disease Detection, Schemes, Voice, and Memory —
each as its own route under `app/`, reusing this shell.
