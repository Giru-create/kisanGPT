"use client";

import { LineChart, ArrowUp, ArrowDown, Minus } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StateMessage } from "@/components/ui/state-message";
import { Badge } from "@/components/ui/badge";
import { useMarketSummary } from "@/lib/hooks/use-dashboard";

const TREND_ICON = { up: ArrowUp, down: ArrowDown, flat: Minus } as const;

export function MarketWidget() {
  const { data, isLoading, isError, refetch } = useMarketSummary();

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <LineChart className="h-4 w-4 text-warning" aria-hidden="true" />
          <CardTitle>Market</CardTitle>
        </div>
        {data && (
          <Badge variant={data.recommendation === "sell" ? "success" : "warning"}>
            {data.recommendation === "sell" ? "Sell now" : "Hold"}
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        )}

        {isError && (
          <StateMessage
            variant="error"
            title="Market data unavailable"
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        )}

        {!isLoading && !isError && data && (
          <>
            <p className="mb-3 text-sm text-muted-foreground">{data.reason}</p>
            <ul className="divide-y divide-border">
              {data.mandis.map((mandi) => {
                const TrendIcon = TREND_ICON[mandi.trend];
                return (
                  <li key={mandi.mandiName} className="flex items-center justify-between py-2.5">
                    <div>
                      <p className="text-sm font-medium">{mandi.mandiName}</p>
                      <p className="text-xs text-muted-foreground">{mandi.distanceKm} km away</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-sm font-medium">
                        ₹{mandi.pricePerQuintal.toLocaleString("en-IN")}
                      </span>
                      <TrendIcon
                        className={
                          mandi.trend === "up"
                            ? "h-3.5 w-3.5 text-success"
                            : mandi.trend === "down"
                            ? "h-3.5 w-3.5 text-destructive"
                            : "h-3.5 w-3.5 text-muted-foreground"
                        }
                        aria-hidden="true"
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}

        {!isLoading && !isError && !data && (
          <StateMessage title="No market data yet" description="Add a crop to your farm profile to see mandi prices." />
        )}
      </CardContent>
    </Card>
  );
}
