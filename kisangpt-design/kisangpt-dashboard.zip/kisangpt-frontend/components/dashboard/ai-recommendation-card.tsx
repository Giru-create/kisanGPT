"use client";

import { motion } from "framer-motion";
import { Sparkles, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StateMessage } from "@/components/ui/state-message";
import { AIThinking } from "@/components/dashboard/ai-thinking";
import { useAIRecommendation } from "@/lib/hooks/use-dashboard";

export function AIRecommendationCard() {
  const { data, isLoading, isError, refetch } = useAIRecommendation();

  return (
    <div className="relative overflow-hidden rounded-lg border border-border bg-gradient-to-br from-primary via-primary to-primary/90 p-6 text-primary-foreground md:p-8">
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          background:
            "radial-gradient(600px 260px at 15% -10%, hsl(var(--accent) / 0.35), transparent 65%)",
        }}
        aria-hidden="true"
      />

      <div className="relative flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-accent">
        <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
        Today&apos;s recommendation
      </div>

      <div className="relative mt-4 min-h-[92px]">
        {isLoading && (
          <div className="space-y-3">
            <AIThinking label="Reading your farm's signals" />
            <Skeleton className="h-6 w-3/4 bg-white/10" />
            <Skeleton className="h-4 w-full bg-white/10" />
          </div>
        )}

        {isError && (
          <StateMessage
            variant="error"
            title="Couldn't load today's recommendation"
            description="Your other farm data below is unaffected. Try again."
            actionLabel="Retry"
            onAction={() => refetch()}
            className="border-white/20 bg-white/5"
          />
        )}

        {!isLoading && !isError && data && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            <p className="font-display text-xl font-semibold leading-snug md:text-2xl">
              {data.headline}
            </p>
            <p className="mt-2 max-w-2xl text-sm text-primary-foreground/80 md:text-[15px]">
              {data.detail}
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Button variant="ai" size="sm">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                Ask a follow-up
              </Button>
              <Button
                variant="secondary"
                size="sm"
                className="border-white/20 bg-white/5 text-primary-foreground hover:bg-white/10"
              >
                <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                Ask by voice
              </Button>
              <span className="ml-auto text-xs text-primary-foreground/60">
                Confidence: {data.confidence}
              </span>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
