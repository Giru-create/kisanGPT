import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import type { RiskLevel } from "@/types/dashboard";

const RISK_STYLES: Record<RiskLevel, string> = {
  low: "text-success bg-success/10",
  medium: "text-warning bg-warning/15",
  high: "text-destructive bg-destructive/10",
};

interface StatCardProps {
  href: string;
  label: string;
  value: string;
  icon: LucideIcon;
  risk?: RiskLevel;
  loading?: boolean;
}

export function StatCard({ href, label, value, icon: Icon, risk, loading }: StatCardProps) {
  if (loading) {
    return (
      <div className="rounded-md border border-border bg-card p-4">
        <Skeleton className="mb-3 h-8 w-8 rounded-sm" />
        <Skeleton className="mb-2 h-3 w-16" />
        <Skeleton className="h-5 w-20" />
      </div>
    );
  }

  return (
    <Link
      href={href}
      className="group flex flex-col rounded-md border border-border bg-card p-4 transition-all duration-200 ease-out hover:-translate-y-0.5 hover:border-input hover:shadow-card"
    >
      <div
        className={cn(
          "mb-3 flex h-9 w-9 items-center justify-center rounded-sm",
          risk ? RISK_STYLES[risk] : "bg-muted text-muted-foreground"
        )}
      >
        <Icon className="h-[18px] w-[18px]" aria-hidden="true" />
      </div>
      <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <span className="mt-1 font-display text-lg font-semibold text-foreground">{value}</span>
    </Link>
  );
}
