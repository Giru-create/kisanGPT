"use client";

import { Landmark } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StateMessage } from "@/components/ui/state-message";
import { useSchemes } from "@/lib/hooks/use-dashboard";

export function SchemeWidget() {
  const { data, isLoading, isError, refetch } = useSchemes();

  return (
    <Card>
      <CardHeader className="flex-row items-center gap-2 space-y-0">
        <Landmark className="h-4 w-4 text-info" aria-hidden="true" />
        <CardTitle>Government schemes</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="space-y-2">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        )}

        {isError && (
          <StateMessage
            variant="error"
            title="Couldn't load schemes"
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        )}

        {!isLoading && !isError && data && data.length === 0 && (
          <StateMessage
            title="No eligible schemes yet"
            description="Complete your farm profile to check eligibility for new schemes."
          />
        )}

        {!isLoading && !isError && data && data.length > 0 && (
          <ul className="space-y-2">
            {data.map((scheme) => (
              <li key={scheme.id} className="rounded-sm border border-border p-3">
                <p className="text-sm font-medium">{scheme.name}</p>
                <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
                {scheme.deadline && (
                  <p className="mt-1 text-[11px] font-medium text-warning">
                    Apply by {scheme.deadline}
                  </p>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
