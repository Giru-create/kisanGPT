export function AIThinking({ label = "KisanGPT is thinking" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2" role="status" aria-live="polite">
      <span className="flex gap-1">
        <span className="h-1.5 w-1.5 animate-bounce-dot rounded-full bg-accent [animation-delay:0ms]" />
        <span className="h-1.5 w-1.5 animate-bounce-dot rounded-full bg-accent [animation-delay:150ms]" />
        <span className="h-1.5 w-1.5 animate-bounce-dot rounded-full bg-accent [animation-delay:300ms]" />
      </span>
      <span className="text-sm text-muted-foreground">{label}…</span>
    </div>
  );
}
