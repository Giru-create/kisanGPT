"use client";

import { CloudSun } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StateMessage } from "@/components/ui/state-message";
import { Badge } from "@/components/ui/badge";
import { useWeatherSummary } from "@/lib/hooks/use-dashboard";

const RISK_BADGE = { low: "success", medium: "warning", high: "destructive" } as const;

export function WeatherWidget() {
  const { data, isLoading, isError, refetch } = useWeatherSummary();

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <CloudSun className="h-4 w-4 text-info" aria-hidden="true" />
          <CardTitle>Weather</CardTitle>
        </div>
        {data && (
          <Badge variant={RISK_BADGE[data.riskLevel]}>{data.riskLevel} risk</Badge>
        )}
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="space-y-3">
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-4 w-full" />
            <div className="flex gap-2 pt-2">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-16 flex-1" />
              ))}
            </div>
          </div>
        )}

        {isError && (
          <StateMessage
            variant="error"
            title="Weather data unavailable"
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        )}

        {!isLoading && !isError && data && (
          <>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-2xl font-medium">{data.todayTempC}°C</span>
              <span className="text-sm text-muted-foreground">{data.condition}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{data.irrigationAdvice}</p>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {data.forecast.slice(0, 3).map((day) => (
                <div key={day.day} className="rounded-sm bg-muted px-2 py-2 text-center">
                  <p className="text-[11px] font-medium text-muted-foreground">{day.day}</p>
                  <p className="font-mono text-sm font-medium">{day.tempC}°</p>
                  <p className="text-[11px] text-info">{day.rainChancePercent}%</p>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
