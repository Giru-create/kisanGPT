"use client";

import { ScanLine, Camera } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StateMessage } from "@/components/ui/state-message";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useDiseaseAlerts } from "@/lib/hooks/use-dashboard";

const SEVERITY_BADGE = { low: "success", medium: "warning", high: "destructive" } as const;

export function DiseaseWidget() {
  const { data, isLoading, isError, refetch } = useDiseaseAlerts();

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <ScanLine className="h-4 w-4 text-destructive" aria-hidden="true" />
          <CardTitle>Crop health</CardTitle>
        </div>
        <Button variant="ghost" size="sm">
          <Camera className="h-3.5 w-3.5" aria-hidden="true" />
          Scan a leaf
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="space-y-2">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        )}

        {isError && (
          <StateMessage
            variant="error"
            title="Couldn't load crop health alerts"
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        )}

        {!isLoading && !isError && data && data.length === 0 && (
          <StateMessage
            title="No issues detected"
            description="All scanned fields look healthy. Scan a new leaf anytime for a fast diagnosis."
          />
        )}

        {!isLoading && !isError && data && data.length > 0 && (
          <ul className="space-y-2">
            {data.map((alert) => (
              <li
                key={alert.id}
                className="flex items-start justify-between gap-3 rounded-sm border border-border p-3"
              >
                <div>
                  <p className="text-sm font-medium">
                    {alert.crop} — {alert.fieldName}
                  </p>
                  <p className="text-xs text-muted-foreground">{alert.issue}</p>
                </div>
                <Badge variant={SEVERITY_BADGE[alert.severity]}>{alert.severity}</Badge>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
