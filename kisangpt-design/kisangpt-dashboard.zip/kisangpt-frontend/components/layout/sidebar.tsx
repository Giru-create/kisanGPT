"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Sparkles,
  CloudSun,
  LineChart,
  ScanLine,
  Landmark,
  Mic,
  Brain,
  User,
  Settings,
  ChevronsLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/use-app-store";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/advisor", label: "AI advisor", icon: Sparkles },
  { href: "/weather", label: "Weather", icon: CloudSun },
  { href: "/market", label: "Market", icon: LineChart },
  { href: "/disease-detection", label: "Disease detection", icon: ScanLine },
  { href: "/schemes", label: "Government schemes", icon: Landmark },
  { href: "/voice", label: "Voice assistant", icon: Mic },
  { href: "/memory", label: "Memory", icon: Brain },
] as const;

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar } = useAppStore();

  return (
    <aside
      className={cn(
        "hidden shrink-0 flex-col border-r border-border bg-card transition-all duration-200 ease-out md:flex",
        sidebarCollapsed ? "w-[76px]" : "w-[240px]"
      )}
      aria-label="Primary navigation"
    >
      <div className="flex h-16 items-center gap-2 px-4">
        <div className="h-7 w-7 shrink-0 rounded-md bg-gradient-to-br from-primary to-accent" />
        {!sidebarCollapsed && (
          <span className="font-display text-sm font-semibold">KisanGPT</span>
        )}
      </div>

      <nav className="flex-1 space-y-1 px-3 py-2">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex h-11 items-center gap-3 rounded-sm px-3 text-sm font-medium transition-colors duration-150",
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden="true" />
              {!sidebarCollapsed && <span className="truncate">{label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="space-y-1 border-t border-border px-3 py-3">
        <Link
          href="/profile"
          className="flex h-11 items-center gap-3 rounded-sm px-3 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <User className="h-[18px] w-[18px] shrink-0" aria-hidden="true" />
          {!sidebarCollapsed && "Profile"}
        </Link>
        <Link
          href="/settings"
          className="flex h-11 items-center gap-3 rounded-sm px-3 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <Settings className="h-[18px] w-[18px] shrink-0" aria-hidden="true" />
          {!sidebarCollapsed && "Settings"}
        </Link>
        <button
          onClick={toggleSidebar}
          className="flex h-11 w-full items-center gap-3 rounded-sm px-3 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronsLeft
            className={cn("h-[18px] w-[18px] shrink-0 transition-transform duration-200", sidebarCollapsed && "rotate-180")}
            aria-hidden="true"
          />
          {!sidebarCollapsed && "Collapse"}
        </button>
      </div>
    </aside>
  );
}
