"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Sparkles, CloudSun, LineChart, Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/use-app-store";

const PRIMARY_ITEMS = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/advisor", label: "Advisor", icon: Sparkles },
  { href: "/weather", label: "Weather", icon: CloudSun },
  { href: "/market", label: "Market", icon: LineChart },
] as const;

export function MobileNav() {
  const pathname = usePathname();
  const setMobileNavOpen = useAppStore((s) => s.setMobileNavOpen);

  return (
    <nav
      aria-label="Primary navigation"
      className="fixed inset-x-0 bottom-0 z-40 flex h-16 items-center justify-around border-t border-border bg-card/95 backdrop-blur md:hidden"
    >
      {PRIMARY_ITEMS.map(({ href, label, icon: Icon }) => {
        const active = pathname === href;
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex h-full min-w-[56px] flex-col items-center justify-center gap-1 text-[11px] font-medium",
              active ? "text-primary" : "text-muted-foreground"
            )}
          >
            <Icon className="h-5 w-5" aria-hidden="true" />
            {label}
          </Link>
        );
      })}
      <button
        onClick={() => setMobileNavOpen(true)}
        aria-label="More options"
        className="flex h-full min-w-[56px] flex-col items-center justify-center gap-1 text-[11px] font-medium text-muted-foreground"
      >
        <Menu className="h-5 w-5" aria-hidden="true" />
        More
      </button>
    </nav>
  );
}
