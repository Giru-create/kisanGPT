"use client";

import { CloudSun, LineChart, HeartPulse, ScanLine } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { AIRecommendationCard } from "@/components/dashboard/ai-recommendation-card";
import { StatCard } from "@/components/dashboard/stat-card";
import { WeatherWidget } from "@/components/dashboard/weather-widget";
import { MarketWidget } from "@/components/dashboard/market-widget";
import { DiseaseWidget } from "@/components/dashboard/disease-widget";
import { SchemeWidget } from "@/components/dashboard/scheme-widget";
import {
  useWeatherSummary,
  useMarketSummary,
  useDiseaseAlerts,
  useCropHealthScore,
} from "@/lib/hooks/use-dashboard";

export default function DashboardPage() {
  const weather = useWeatherSummary();
  const market = useMarketSummary();
  const disease = useDiseaseAlerts();
  const health = useCropHealthScore();

  const loading = weather.isLoading || market.isLoading || disease.isLoading || health.isLoading;

  return (
    <AppShell>
      <header className="mb-6">
        <h1 className="font-display text-2xl font-semibold">Good morning</h1>
        <p className="text-sm text-muted-foreground">Here&apos;s what needs your attention today.</p>
      </header>

      <section aria-label="AI recommendation" className="mb-6">
        <AIRecommendationCard />
      </section>

      <section aria-label="Farm signals" className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard
          href="/weather"
          label="Weather"
          value={weather.data ? `${weather.data.todayTempC}°C` : "—"}
          icon={CloudSun}
          risk={weather.data?.riskLevel}
          loading={loading}
        />
        <StatCard
          href="/market"
          label="Market"
          value={market.data ? market.data.recommendation : "—"}
          icon={LineChart}
          loading={loading}
        />
        <StatCard
          href="/disease-detection"
          label="Crop health"
          value={health.data != null ? `${health.data}/100` : "—"}
          icon={HeartPulse}
          risk={health.data != null ? (health.data > 75 ? "low" : health.data > 45 ? "medium" : "high") : undefined}
          loading={loading}
        />
        <StatCard
          href="/disease-detection"
          label="Alerts"
          value={disease.data ? String(disease.data.length) : "—"}
          icon={ScanLine}
          risk={disease.data && disease.data.length > 0 ? "high" : "low"}
          loading={loading}
        />
      </section>

      <section aria-label="Details" className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <WeatherWidget />
        <MarketWidget />
        <DiseaseWidget />
        <SchemeWidget />
      </section>
    </AppShell>
  );
}
