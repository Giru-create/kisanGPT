export type RiskLevel = "low" | "medium" | "high";

export interface AIRecommendation {
  id: string;
  headline: string;
  detail: string;
  confidence: "low" | "medium" | "high";
  generatedAt: string;
}

export interface WeatherSummary {
  locationName: string;
  todayTempC: number;
  condition: string;
  rainChancePercent: number;
  riskLevel: RiskLevel;
  forecast: { day: string; tempC: number; rainChancePercent: number }[];
  irrigationAdvice: string;
}

export interface MandiPrice {
  mandiName: string;
  distanceKm: number;
  pricePerQuintal: number;
  trend: "up" | "down" | "flat";
}

export interface MarketSummary {
  crop: string;
  recommendation: "sell" | "hold";
  reason: string;
  mandis: MandiPrice[];
}

export interface DiseaseAlert {
  id: string;
  crop: string;
  fieldName: string;
  issue: string;
  severity: RiskLevel;
  detectedAt: string;
}

export interface SchemeSummary {
  id: string;
  name: string;
  benefit: string;
  deadline: string | null;
  eligible: boolean;
}

export interface DashboardData {
  recommendation: AIRecommendation | null;
  weather: WeatherSummary | null;
  market: MarketSummary | null;
  diseaseAlerts: DiseaseAlert[];
  schemes: SchemeSummary[];
  cropHealthScore: number | null;
}
